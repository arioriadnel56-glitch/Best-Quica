#!/bin/bash
clear

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║   🏪  BEST-QUINCA  —  Installation automatique      ║"
echo "║   Le meilleur choix pour votre gestion              ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

INSTALL_DIR="$HOME/BestQuinca"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ── Étape 1 : Node.js ─────────────────────────────────────────
echo " [1/4] Vérification de Node.js..."

if command -v node &> /dev/null; then
    NODE_VER=$(node --version)
    echo "       ✅ Node.js déjà installé : $NODE_VER"
else
    echo "       ⬇️  Installation de Node.js..."
    
    # Détecter la distribution
    if command -v apt-get &> /dev/null; then
        # Debian/Ubuntu
        echo "       Détecté : Ubuntu/Debian"
        curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - 2>/dev/null
        sudo apt-get install -y nodejs 2>/dev/null
    elif command -v dnf &> /dev/null; then
        # Fedora/RHEL
        echo "       Détecté : Fedora/RHEL"
        curl -fsSL https://rpm.nodesource.com/setup_20.x | sudo bash - 2>/dev/null
        sudo dnf install -y nodejs 2>/dev/null
    elif command -v pacman &> /dev/null; then
        # Arch Linux
        echo "       Détecté : Arch Linux"
        sudo pacman -S --noconfirm nodejs npm 2>/dev/null
    else
        echo "       ❌ Distribution non reconnue."
        echo "          Installez Node.js depuis : https://nodejs.org"
        echo "          Puis relancez ce script."
        read -p "Appuyez sur Entrée..."
        exit 1
    fi
    
    if ! command -v node &> /dev/null; then
        echo "       ❌ Échec installation Node.js"
        echo "          Installez manuellement depuis https://nodejs.org"
        exit 1
    fi
    echo "       ✅ Node.js installé : $(node --version)"
fi

echo ""

# ── Étape 2 : Copier l'application ────────────────────────────
echo " [2/4] Installation de l'application..."
mkdir -p "$INSTALL_DIR"
cp -r "$SCRIPT_DIR/app" "$INSTALL_DIR/"
echo "       ✅ Fichiers copiés dans $INSTALL_DIR"
echo ""

# ── Étape 3 : Installer les dépendances ───────────────────────
echo " [3/4] Installation des dépendances..."

cd "$INSTALL_DIR/app/backend"
npm install --production --silent 2>/dev/null
echo "       ✅ Backend prêt"

cd "$INSTALL_DIR/app/frontend"
npm install --silent 2>/dev/null
echo "       ✅ Dépendances frontend"
echo "       🔨 Compilation de l'interface (1-2 minutes)..."
npm run build --silent 2>/dev/null
echo "       ✅ Interface compilée"
echo ""

# ── Étape 4 : Créer raccourcis et scripts ─────────────────────
echo " [4/4] Création des raccourcis..."

# Script de lancement
LAUNCHER="$INSTALL_DIR/lancer-bestquinca.sh"
cat > "$LAUNCHER" << LAUNCH
#!/bin/bash
echo "🏪 Démarrage de Best-Quinca..."
cd "$INSTALL_DIR/app/backend"
node server.js &
BACKEND_PID=\$!
sleep 2
if command -v xdg-open &>/dev/null; then
    xdg-open http://localhost:8081 2>/dev/null
elif command -v firefox &>/dev/null; then
    firefox http://localhost:8081 &
elif command -v google-chrome &>/dev/null; then
    google-chrome http://localhost:8081 &
fi
echo "✅ Best-Quinca démarré sur http://localhost:8081"
echo "Appuyez sur Ctrl+C pour arrêter."
wait \$BACKEND_PID
LAUNCH
chmod +x "$LAUNCHER"

# Raccourci .desktop (Linux)
DESKTOP_FILE="$HOME/Desktop/bestquinca.desktop"
cat > "$DESKTOP_FILE" << DESKTOP
[Desktop Entry]
Version=1.0
Type=Application
Name=Best-Quinca
Comment=Logiciel de gestion pour quincailleries
Exec=bash $LAUNCHER
Icon=$INSTALL_DIR/app/frontend/public/logo192.png
Terminal=true
Categories=Office;Finance;
StartupNotify=true
DESKTOP
chmod +x "$DESKTOP_FILE" 2>/dev/null

# Aussi dans ~/.local/share/applications pour le menu
mkdir -p "$HOME/.local/share/applications"
cp "$DESKTOP_FILE" "$HOME/.local/share/applications/bestquinca.desktop" 2>/dev/null

echo "       ✅ Raccourci créé sur le Bureau"
echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║  🎉  Installation terminée avec succès !             ║"
echo "║                                                      ║"
echo "║  ➡️   Double-cliquez sur « Best-Quinca »             ║"
echo "║      sur votre Bureau pour lancer                   ║"
echo "║                                                      ║"
echo "║  🌐  Adresse locale : http://localhost:8081          ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

read -p " Lancer Best-Quinca maintenant ? (o/n) : " LAUNCH_NOW
if [[ "$LAUNCH_NOW" =~ ^[Oo]$ ]]; then
    bash "$LAUNCHER"
fi
