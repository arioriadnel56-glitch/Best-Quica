@echo off
chcp 65001 > nul
setlocal EnableDelayedExpansion
title Best-Quinca — Installation

echo.
echo  ╔══════════════════════════════════════════════════════╗
echo  ║   🏪  BEST-QUINCA  —  Installation automatique      ║
echo  ║   Le meilleur choix pour votre gestion              ║
echo  ╚══════════════════════════════════════════════════════╝
echo.

:: ── Choisir le dossier d'installation ────────────────────────
set "INSTALL_DIR=%USERPROFILE%\BestQuinca"
echo  📁 Dossier d'installation : %INSTALL_DIR%
echo.

:: ── Étape 1 : Vérifier / Installer Node.js ───────────────────
echo  [1/4] Vérification de Node.js...
node --version > nul 2>&1
if %errorlevel% equ 0 (
    echo       ✅ Node.js est déjà installé : 
    node --version
) else (
    echo       ⬇️  Node.js non trouvé. Téléchargement en cours...
    echo       (Cette étape peut prendre 1-2 minutes selon votre connexion)
    echo.

    :: Télécharger l'installateur Node.js LTS silencieusement
    set "NODE_URL=https://nodejs.org/dist/v20.11.0/node-v20.11.0-x64.msi"
    set "NODE_MSI=%TEMP%\node-installer.msi"

    :: Utiliser PowerShell pour télécharger
    powershell -Command "& {[Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -Uri '%NODE_URL%' -OutFile '%NODE_MSI%' -UseBasicParsing}" 2>nul

    if not exist "%NODE_MSI%" (
        echo.
        echo  ❌ Téléchargement impossible.
        echo     Installez Node.js manuellement depuis : https://nodejs.org
        echo     Puis relancez ce fichier.
        pause
        exit /b 1
    )

    echo       Installation de Node.js (merci de patienter)...
    msiexec /i "%NODE_MSI%" /quiet /norestart ADDLOCAL="NodeRuntime,npm"
    del "%NODE_MSI%" > nul 2>&1

    :: Rafraîchir le PATH
    set "PATH=%PATH%;%ProgramFiles%\nodejs"

    node --version > nul 2>&1
    if %errorlevel% neq 0 (
        echo  ❌ Echec installation Node.js. Redémarrez le PC et relancez.
        pause
        exit /b 1
    )
    echo       ✅ Node.js installé avec succès !
)

echo.

:: ── Étape 2 : Copier l'application ───────────────────────────
echo  [2/4] Copie de l'application...

if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

:: Copier les fichiers app
xcopy /E /I /Y /Q "app" "%INSTALL_DIR%\app" > nul
echo       ✅ Fichiers copiés dans %INSTALL_DIR%

echo.

:: ── Étape 3 : Installer les dépendances ──────────────────────
echo  [3/4] Installation des dépendances (1-3 minutes)...

cd /d "%INSTALL_DIR%\app\backend"
call npm install --production --silent 2>nul
if %errorlevel% neq 0 (
    call npm install --production 2>&1 | findstr "error" | head -3
    echo  ⚠️  Avertissement pendant l'installation backend
)
echo       ✅ Backend prêt

cd /d "%INSTALL_DIR%\app\frontend"
call npm install --silent 2>nul
echo       ✅ Dépendances frontend installées

echo       🔨 Compilation de l'interface (1-2 minutes)...
call npm run build --silent 2>nul
echo       ✅ Interface compilée

echo.

:: ── Étape 4 : Créer les raccourcis ───────────────────────────
echo  [4/4] Création des raccourcis...

:: Créer le script de lancement final
set "LAUNCHER=%INSTALL_DIR%\Lancer-BestQuinca.bat"
(
echo @echo off
echo chcp 65001 ^> nul
echo title Best-Quinca
echo.
echo echo  🏪 Démarrage de Best-Quinca...
echo cd /d "%INSTALL_DIR%\app\backend"
echo start /B "" node server.js
echo timeout /t 3 /nobreak ^> nul
echo start http://localhost:8081
echo echo.
echo echo  ✅ Best-Quinca ouvert dans votre navigateur
echo echo  Adresse : http://localhost:8081
echo echo.
echo echo  ⚠️  Ne fermez PAS cette fenêtre
echo echo  Appuyez sur Ctrl+C pour arrêter
echo :loop
echo timeout /t 30 /nobreak ^> nul
echo goto loop
) > "%LAUNCHER%"

:: Raccourci Bureau via PowerShell
powershell -Command "& {$s=(New-Object -COM WScript.Shell).CreateShortcut('%USERPROFILE%\Desktop\Best-Quinca.lnk'); $s.TargetPath='%LAUNCHER%'; $s.WorkingDirectory='%INSTALL_DIR%'; $s.IconLocation='%INSTALL_DIR%\app\frontend\public\logo192.png'; $s.Description='Best-Quinca - Gestion Quincaillerie'; $s.Save()}" 2>nul

:: Raccourci Menu Démarrer
set "STARTMENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs"
if not exist "%STARTMENU%\Best-Quinca" mkdir "%STARTMENU%\Best-Quinca"
powershell -Command "& {$s=(New-Object -COM WScript.Shell).CreateShortcut('%STARTMENU%\Best-Quinca\Best-Quinca.lnk'); $s.TargetPath='%LAUNCHER%'; $s.WorkingDirectory='%INSTALL_DIR%'; $s.Description='Best-Quinca'; $s.Save()}" 2>nul

echo       ✅ Raccourci créé sur le Bureau et dans le Menu Démarrer

echo.
echo  ╔══════════════════════════════════════════════════════╗
echo  ║  🎉  Installation terminée avec succès !             ║
echo  ║                                                      ║
echo  ║  ➡️   Lancez Best-Quinca depuis votre Bureau         ║
echo  ║      ou depuis le Menu Démarrer                     ║
echo  ║                                                      ║
echo  ║  🌐  Adresse locale : http://localhost:8081          ║
echo  ╚══════════════════════════════════════════════════════╝
echo.

:: Proposer de lancer immédiatement
set /p LAUNCH="  Voulez-vous lancer Best-Quinca maintenant ? (O/N) : "
if /i "%LAUNCH%"=="O" (
    start "" "%LAUNCHER%"
)

echo.
pause
