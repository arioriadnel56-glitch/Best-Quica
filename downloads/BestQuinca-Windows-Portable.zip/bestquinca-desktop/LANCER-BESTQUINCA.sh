#!/bin/bash
clear
echo ""
echo "╔════════════════════════════════════════════════╗"
echo "║     🏪  BEST-QUINCA  —  Démarrage             ║"
echo "║     Le meilleur choix pour votre gestion       ║"
echo "╚════════════════════════════════════════════════╝"
echo ""

# Vérifier Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js n'est pas installé."
    echo ""
    echo "Installez-le depuis : https://nodejs.org"
    echo ""
    exit 1
fi

echo "✅ Node.js : $(node --version)"
echo ""

# Backend — installer si nécessaire
if [ ! -d "backend/node_modules" ]; then
    echo "📦 Installation backend..."
    cd backend && npm install --production --silent && cd ..
fi

# Frontend — compiler si nécessaire
if [ ! -d "frontend/dist" ]; then
    echo "📦 Installation et compilation frontend..."
    cd frontend && npm install --silent && npm run build --silent && cd ..
fi

echo "🚀 Démarrage de Best-Quinca..."
echo ""

# Démarrer le backend
node backend/server.js &
BACKEND_PID=$!

sleep 2

# Ouvrir dans le navigateur
if command -v xdg-open &> /dev/null; then
    xdg-open http://localhost:8081
elif command -v open &> /dev/null; then
    open http://localhost:8081
fi

echo "╔════════════════════════════════════════════════╗"
echo "║  ✅ Best-Quinca est démarré !                  ║"
echo "║                                                ║"
echo "║  Adresse : http://localhost:8081               ║"
echo "║                                                ║"
echo "║  Appuyez sur Ctrl+C pour arrêter               ║"
echo "╚════════════════════════════════════════════════╝"
echo ""

# Attendre
wait $BACKEND_PID
