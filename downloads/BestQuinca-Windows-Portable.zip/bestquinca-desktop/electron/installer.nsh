# Personnalisation de l'installateur Best-Quinca
!macro customHeader
  !system "echo Installation Best-Quinca"
!macroend

!macro customInstall
  # Créer un raccourci sur le bureau
  CreateShortCut "$DESKTOP\Best-Quinca.lnk" "$INSTDIR\Best-Quinca.exe"
!macroend
