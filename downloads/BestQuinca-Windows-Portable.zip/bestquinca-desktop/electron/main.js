/**
 * BEST-QUINCA — Electron Main Process
 * Lance le backend Express + ouvre la fenêtre Electron
 */
const { app, BrowserWindow, shell, Menu, Tray, dialog, nativeImage } = require('electron');
const path   = require('path');
const http   = require('http');
const fs     = require('fs');

// ── Chemins ────────────────────────────────────────────────────
const isDev       = !app.isPackaged;
const BACKEND_DIR = isDev
  ? path.join(__dirname, '..', 'backend')
  : path.join(process.resourcesPath, 'backend');

const FRONTEND_DIR = isDev
  ? path.join(__dirname, '..', 'frontend', 'dist')
  : path.join(__dirname, '..', 'frontend', 'dist');

const BACKEND_PORT  = 8081;
const FRONTEND_PORT = 8000;

let mainWindow = null;
let tray       = null;
let backendReady = false;

// ── Démarrer le backend Express ────────────────────────────────
function startBackend() {
  // Pointer la DB dans le dossier userData (persistant entre les mises à jour)
  const userDataPath = app.getPath('userData');
  const dbPath = path.join(userDataPath, 'bestquinca.db');
  process.env.DB_PATH      = dbPath;
  process.env.PORT         = String(BACKEND_PORT);
  process.env.FRONTEND_URL = `http://localhost:${FRONTEND_PORT}`;
  process.env.JWT_SECRET   = 'bestquinca_secret_electron_2024';
  process.env.NODE_ENV     = 'production';

  // Copier node_modules du backend si nécessaire (dans resourcesPath)
  try {
    require(path.join(BACKEND_DIR, 'server.js'));
    console.log(`✅ Backend démarré sur port ${BACKEND_PORT}`);
    backendReady = true;
  } catch (e) {
    console.error('Erreur backend:', e);
    dialog.showErrorBox('Erreur Best-Quinca', 
      `Impossible de démarrer le serveur.\n\nDétails: ${e.message}`);
  }
}

// ── Attendre que le backend soit prêt ─────────────────────────
function waitForBackend(callback, retries = 30) {
  http.get(`http://localhost:${BACKEND_PORT}/api/health`, (res) => {
    if (res.statusCode === 200) {
      callback();
    } else {
      retry(callback, retries);
    }
  }).on('error', () => retry(callback, retries));
}

function retry(callback, retries) {
  if (retries <= 0) {
    dialog.showErrorBox('Best-Quinca', 'Le serveur met trop de temps à démarrer. Relancez l\'application.');
    return;
  }
  setTimeout(() => waitForBackend(callback, retries - 1), 500);
}

// ── Créer la fenêtre principale ────────────────────────────────
function createWindow() {
  const iconPath = path.join(__dirname, '..', 'frontend', 'public', 'logo192.png');

  mainWindow = new BrowserWindow({
    width:  1280,
    height: 800,
    minWidth:  1024,
    minHeight: 640,
    title: 'Best-Quinca',
    icon:  iconPath,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    },
    show: false,
    backgroundColor: '#f1f5f9',
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
  });

  // Splash screen pendant le chargement
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    mainWindow.focus();
  });

  // Charger l'application
  mainWindow.loadURL(`http://localhost:${BACKEND_PORT}`);

  // Ouvrir les liens externes dans le navigateur
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('http')) shell.openExternal(url);
    return { action: 'deny' };
  });

  mainWindow.on('closed', () => { mainWindow = null; });

  // Menu de l'application
  buildMenu();
}

// ── Menu ───────────────────────────────────────────────────────
function buildMenu() {
  const template = [
    {
      label: 'Best-Quinca',
      submenu: [
        { label: 'À propos de Best-Quinca', role: 'about' },
        { type: 'separator' },
        {
          label: 'Recharger',
          accelerator: 'CmdOrCtrl+R',
          click: () => mainWindow?.reload()
        },
        { type: 'separator' },
        { label: 'Quitter', accelerator: 'CmdOrCtrl+Q', click: () => app.quit() }
      ]
    },
    {
      label: 'Affichage',
      submenu: [
        { label: 'Plein écran', accelerator: 'F11', role: 'togglefullscreen' },
        { label: 'Zoom avant', accelerator: 'CmdOrCtrl+=', role: 'zoomIn' },
        { label: 'Zoom arrière', accelerator: 'CmdOrCtrl+-', role: 'zoomOut' },
        { label: 'Taille normale', accelerator: 'CmdOrCtrl+0', role: 'resetZoom' },
      ]
    },
    {
      label: 'Aide',
      submenu: [
        {
          label: 'Ouvrir dans le navigateur',
          click: () => shell.openExternal(`http://localhost:${BACKEND_PORT}`)
        },
        {
          label: 'Dossier des données',
          click: () => shell.openPath(app.getPath('userData'))
        },
        { type: 'separator' },
        {
          label: `Version 1.0.0 — Port ${BACKEND_PORT}`,
          enabled: false
        }
      ]
    }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// ── Tray (icône dans la barre des tâches) ─────────────────────
function createTray() {
  const iconPath = path.join(__dirname, '..', 'frontend', 'public', 'logo192.png');
  try {
    tray = new Tray(iconPath);
    tray.setToolTip('Best-Quinca — En cours d\'exécution');
    tray.setContextMenu(Menu.buildFromTemplate([
      { label: 'Ouvrir Best-Quinca', click: () => { mainWindow?.show(); mainWindow?.focus(); } },
      { type: 'separator' },
      { label: 'Quitter', click: () => app.quit() }
    ]));
    tray.on('double-click', () => { mainWindow?.show(); mainWindow?.focus(); });
  } catch(e) {
    // Tray optionnel, pas bloquant
  }
}

// ── Cycle de vie Electron ──────────────────────────────────────
app.whenReady().then(() => {
  // Démarrer le backend en premier
  startBackend();

  // Attendre qu'il soit prêt, puis ouvrir la fenêtre
  waitForBackend(() => {
    createWindow();
    createTray();
  });

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('before-quit', () => {
  tray?.destroy();
});
