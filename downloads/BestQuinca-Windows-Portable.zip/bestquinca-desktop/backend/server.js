const express = require('express');
const cors    = require('cors');
const path    = require('path');

require('./database');

const app  = express();
const PORT = process.env.PORT || 8081;

app.use(cors({ origin: '*' }));
app.use(express.json({ limit: '25mb' }));

// Routes API
app.use('/api/auth',      require('./routes/auth'));
app.use('/api/clients',   require('./routes/clients'));
app.use('/api/materials', require('./routes/materials'));
app.use('/api/invoices',  require('./routes/invoices'));
app.use('/api/sales',     require('./routes/sales'));
app.use('/api/trucks',    require('./routes/trucks'));
app.use('/api/team',      require('./routes/team'));
app.use('/api/backup',    require('./routes/backup'));

app.get('/api/health', (req, res) => res.json({
  status: 'ok', app: 'Best-Quinca', version: '1.0.0', port: PORT
}));

// Servir le frontend React buildé (mode production/Electron)
const frontendDist = path.join(__dirname, '..', 'frontend', 'dist');
const fs = require('fs');

if (fs.existsSync(frontendDist)) {
  app.use(express.static(frontendDist));
  app.get('*', (req, res) => {
    res.sendFile(path.join(frontendDist, 'index.html'));
  });
}

app.use((err, req, res, next) => {
  console.error(err.message);
  res.status(500).json({ error: 'Erreur serveur.' });
});

app.listen(PORT, '127.0.0.1', () => {
  console.log(`\n🏪 Best-Quinca sur http://localhost:${PORT}\n`);
});
