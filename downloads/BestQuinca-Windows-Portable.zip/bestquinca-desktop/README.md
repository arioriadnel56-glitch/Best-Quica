# 🏪 Best-Quinca — Guide d'installation

---

## 🎯 CE QUE VOUS TROUVEZ DANS CE DOSSIER

Ce dossier contient le **code source** de Best-Quinca.
Pour l'installer en quincaillerie sans aucune configuration, vous avez **2 options** :

---

## ✅ OPTION 1 — Application Bureau (recommandée, zéro terminal)

### Étapes pour créer le fichier `.exe` installable :

**1. Installer Node.js** (une seule fois sur votre PC de développement)
→ Téléchargez sur https://nodejs.org (version LTS)

**2. Ouvrir un terminal dans ce dossier et taper :**
```bash
# Installer les dépendances Electron
npm install

# Builder le frontend React
npm run build-frontend

# Créer l'installateur Windows .exe
npm run dist-win
```

**3. Résultat :** Un fichier `dist-electron/Best-Quinca Setup 1.0.0.exe` sera créé.

**4. Copier ce fichier `.exe` sur votre clé USB** et l'installer dans chaque quincaillerie.

→ **Un double-clic suffit pour installer et lancer Best-Quinca !**

---

## ✅ OPTION 2 — Version portable (sans installation)

Si vous ne pouvez pas compiler, utilisez cette méthode :

**1. Installer Node.js** sur le PC de la quincaillerie (une seule fois)
→ https://nodejs.org

**2. Copier tout ce dossier `bestquinca-desktop` sur la clé USB**

**3. Sur le PC de la quincaillerie :**
- Double-cliquer sur `LANCER-BESTQUINCA.bat` (Windows)
- Ou `bash LANCER-BESTQUINCA.sh` (Linux/Mac)

---

## 📁 Structure
```
bestquinca-desktop/
├── electron/           ← Fichiers Electron (application bureau)
│   └── main.js
├── backend/            ← Serveur API + SQLite
│   ├── routes/
│   ├── database.js
│   └── server.js
├── frontend/           ← Interface React
│   └── src/
├── package.json        ← Configuration Electron Builder
├── LANCER-BESTQUINCA.bat    ← Démarrage Windows (portable)
├── LANCER-BESTQUINCA.sh     ← Démarrage Linux/Mac (portable)
└── README.md
```

---

## 💾 Données
Les données sont sauvegardées automatiquement dans :
- **Windows:** `C:\Users\[nom]\AppData\Roaming\best-quinca\bestquinca.db`
- **Mac:** `~/Library/Application Support/best-quinca/bestquinca.db`
- **Linux:** `~/.config/best-quinca/bestquinca.db`

---
*Best-Quinca v1.0.0 — Le meilleur choix pour votre gestion*
