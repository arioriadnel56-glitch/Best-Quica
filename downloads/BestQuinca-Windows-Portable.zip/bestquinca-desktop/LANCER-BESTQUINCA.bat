@echo off
chcp 65001 > nul
title Best-Quinca — Démarrage en cours...

echo.
echo  ╔════════════════════════════════════════════════╗
echo  ║     🏪  BEST-QUINCA  —  Démarrage             ║
echo  ║     Le meilleur choix pour votre gestion       ║
echo  ╚════════════════════════════════════════════════╝
echo.

:: Vérifier si Node.js est installé
node --version > nul 2>&1
if %errorlevel% neq 0 (
    echo  ❌ Node.js n'est pas installé sur ce PC.
    echo.
    echo  Veuillez télécharger et installer Node.js depuis :
    echo  https://nodejs.org  (choisir la version LTS)
    echo.
    echo  Après installation, relancez ce fichier.
    echo.
    start https://nodejs.org
    pause
    exit /b 1
)

echo  ✅ Node.js détecté : 
node --version
echo.

:: Installer les dépendances si nécessaire
if not exist "backend\node_modules" (
    echo  📦 Installation des dépendances backend...
    cd backend
    npm install --production --silent
    cd ..
    echo  ✅ Backend prêt
)

if not exist "frontend\node_modules" (
    echo  📦 Installation des dépendances frontend...
    cd frontend
    npm install --silent
    echo  🔨 Compilation de l'interface...
    npm run build --silent
    cd ..
    echo  ✅ Frontend prêt
) else if not exist "frontend\dist" (
    echo  🔨 Compilation de l'interface...
    cd frontend
    npm run build --silent
    cd ..
    echo  ✅ Interface compilée
)

echo.
echo  🚀 Démarrage de Best-Quinca...
echo.

:: Démarrer le backend
start /B "BestQuinca-Backend" node backend/server.js

:: Attendre 3 secondes
timeout /t 3 /nobreak > nul

:: Ouvrir dans le navigateur
echo  🌐 Ouverture dans le navigateur...
start http://localhost:8081

echo.
echo  ╔════════════════════════════════════════════════╗
echo  ║  ✅ Best-Quinca est démarré !                  ║
echo  ║                                                ║
echo  ║  Adresse : http://localhost:8081               ║
echo  ║                                                ║
echo  ║  ⚠️  Ne fermez PAS cette fenêtre               ║
echo  ║     tant que vous utilisez le logiciel         ║
echo  ╚════════════════════════════════════════════════╝
echo.
echo  Appuyez sur Ctrl+C pour arrêter Best-Quinca.
echo.

:: Garder le script en vie pour que le backend tourne
:loop
timeout /t 10 /nobreak > nul
goto loop
