import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      manifest: {
        name: 'Best-Quinca — Gestion Quincaillerie',
        short_name: 'Best-Quinca',
        theme_color: '#1e3a5f',
        description: 'Le meilleur choix pour votre gestion',
        background_color: '#f1f5f9',
        display: 'standalone',
        icons: [
          { src: 'logo192.png', sizes: '192x192', type: 'image/png' },
          { src: 'logo512.png', sizes: '512x512', type: 'image/png' }
        ]
      }
    })
  ],
  // En production Electron: le backend et le frontend tournent sur le même port
  // L'API est donc sur la même origine, pas besoin de proxy
  server: {
    port: 8000,
    strictPort: true,
    proxy: {
      '/api': {
        target: 'http://localhost:8081',
        changeOrigin: true
      }
    }
  },
  preview: { port: 8000 }
});
